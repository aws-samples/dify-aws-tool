import json
import base64
import yaml

invalid_error = {
    'statusCode': 400,
    'body': json.dumps('Invalid Request.')
}

def lambda_handler(event, context):
    body = event.get('body')
    qs = event.get('queryStringParameters', {})
    if qs.get('vv', '1'):
        print(event, context)

    if not body:
        return invalid_error

    isB64= event.get('isBase64Encoded')
    if isB64:
        body = base64.b64decode(body).decode('utf-8').replace("\\n", "\n")
        print(body)


    return {
        'statusCode': 200,
        'body': json.dumps({'json': yaml.safe_load(body)})
    }